# Matrix-Arduino-Animation
This project consists in designing a wearable matrix used to display some animations. They can be changed using BluefruitConnect Mobile App through bluetooth. This project made me familiar with Arduino.
