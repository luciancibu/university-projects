function bibliografie
open('bibliografie.pdf');