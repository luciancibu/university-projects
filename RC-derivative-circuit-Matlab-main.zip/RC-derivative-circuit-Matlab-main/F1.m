function dy=F1(t,y,flag,E,R,C)
dy=(E-y)./(R.*C);
