function dy=F2(t,y,flag,E,R,C)
dy = -y./(R.*C);