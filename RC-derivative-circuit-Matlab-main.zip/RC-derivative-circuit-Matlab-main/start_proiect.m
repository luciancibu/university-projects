clear all;
close all;

R=9;
C=4;
T=6;
E=8;
N=3;
D=0.5;




interfata(R,C,T,E,N,D);