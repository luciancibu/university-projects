function teorie
open('teorie.pdf');