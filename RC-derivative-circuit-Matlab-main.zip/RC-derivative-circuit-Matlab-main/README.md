# RC-derivative-circuit-Matlab
Circuit simulation using Matlab (including UI with text area and push buttons)
