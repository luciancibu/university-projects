# ClientServerCommunication
Using socket programming and IPV4
