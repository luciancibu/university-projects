# PWM-Generator
Pulse Width Modulation generation knowing frequency limits and and amplitude using OrCAD design software
