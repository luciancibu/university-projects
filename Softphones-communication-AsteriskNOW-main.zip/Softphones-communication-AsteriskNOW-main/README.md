# Softphones-communication-AsteriskNOW
Implementation of a PBX IP software AsteriskNOW version installed on CentOS virtual machine. Used software phones are X-Lite/Bria (SIP protocolul) and ZoIPer (IAX2 and SIP protocols). Created a dial plan with those functions:
## CONFERENCING
* MeetMe: Simple MeetMe conference bridge,
* MeetMeAdmin: MeetMe conference Administration,
* MeetMeCount: MeetMe participant count
## RECORD
* Dictate: Records and plays back a dictation,
* Monitor: Record a telephone conversation to a sound file,
* Record: Record user voice input to a file 
